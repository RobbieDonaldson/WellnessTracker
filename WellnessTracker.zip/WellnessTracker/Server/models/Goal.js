const mongoose = require("mongoose");

const goalSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    title: {
      type: String,
      required: [true, "Goal title is required"],
      trim: true,
      maxlength: 200,
    },
    category: {
      type: String,
      required: [true, "Category is required"],
      enum: ["activity", "nutrition", "sleep", "weight", "hydration", "blood_pressure", "blood_glucose", "heart_rate", "journal"],
    },
    targetValue: {
      type: Number,
      required: [true, "Target value is required"],
      min: 0,
    },
    currentValue: {
      type: Number,
      default: 0,
      min: 0,
    },
    unit: {
      type: String,
      trim: true,
      maxlength: 50,
    },
    threshold: {
      type: Number,
      min: 0,
    },
    thresholdUnit: {
      type: String,
      trim: true,
      maxlength: 50,
    },
    startDate: {
      type: Date,
      default: Date.now,
    },
    endDate: {
      type: Date,
      required: [true, "End date is required"],
    },
    completed: {
      type: Boolean,
      default: false,
    },
    notes: {
      type: String,
      trim: true,
      maxlength: 500,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Goal", goalSchema);
