const GoalProgressStrategy = require("./GoalProgressStrategy");
const { unitMatches } = require("../utils/unitNormalizer");

class BloodGlucoseStrategy extends GoalProgressStrategy {
  async computeCurrentValue(goal) {
    const dateFilter = this.buildDateFilter(goal);
    const unit = goal.unit || "";

    // Days: count of days with average glucose below threshold (from explicit threshold field, fallback to 100)
    if (unitMatches(unit, "day")) {
      const threshold = goal.threshold || 100;
      const agg = await this.models.BloodGlucose.aggregate([
        { $match: dateFilter },
        { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } }, avg: { $avg: "$level" } } },
        { $match: { avg: { $lt: threshold } } },
      ]);
      return agg.length;
    }

    // Readings: count of entries
    if (unitMatches(unit, "reading")) {
      return await this.models.BloodGlucose.countDocuments(dateFilter);
    }

    // mg/dL: average glucose level
    if (unitMatches(unit, "mgdl")) {
      const agg = await this.models.BloodGlucose.aggregate([
        { $match: dateFilter },
        { $group: { _id: null, avg: { $avg: "$level" } } },
      ]);
      return Math.round(agg[0]?.avg || 0);
    }

    // Default: count of entries
    return await this.models.BloodGlucose.countDocuments(dateFilter);
  }

  /**
   * For "keep under" goals (mg/dL), being at or below target = success.
   */
  getProgress(goal) {
    const gUnit = goal.unit || "";
    const isKeepUnder = unitMatches(gUnit, "mgdl");

    if (isKeepUnder && goal.targetValue > 0) {
      const completed = goal.currentValue <= goal.targetValue;
      return completed ? 100 : (goal.currentValue > 0 ? Math.max(0, Math.min(Math.round(((goal.targetValue / goal.currentValue)) * 100), 99)) : 0);
    }
    return super.getProgress(goal);
  }

  isCompleted(goal) {
    const gUnit = goal.unit || "";
    const isKeepUnder = unitMatches(gUnit, "mgdl");
    if (isKeepUnder && goal.targetValue > 0) {
      return goal.currentValue <= goal.targetValue;
    }
    return super.isCompleted(goal);
  }
}

module.exports = BloodGlucoseStrategy;
