const GoalProgressStrategy = require("./GoalProgressStrategy");
const { unitMatches } = require("../utils/unitNormalizer");

class BloodPressureStrategy extends GoalProgressStrategy {
  async computeCurrentValue(goal) {
    const dateFilter = this.buildDateFilter(goal);
    const unit = goal.unit || "";

    // Days: count of days with BP < 130/85
    if (unitMatches(unit, "day")) {
      const agg = await this.models.BloodPressure.aggregate([
        { $match: { ...dateFilter, systolic: { $lt: 130 }, diastolic: { $lt: 85 } } },
        { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } } } },
      ]);
      return agg.length;
    }

    // Readings: count of entries
    if (unitMatches(unit, "reading")) {
      return await this.models.BloodPressure.countDocuments(dateFilter);
    }

    // mmHg/systolic: average systolic
    if (unitMatches(unit, "mmhg")) {
      const agg = await this.models.BloodPressure.aggregate([
        { $match: dateFilter },
        { $group: { _id: null, avg: { $avg: "$systolic" } } },
      ]);
      return Math.round(agg[0]?.avg || 0);
    }

    // Default: count of entries
    return await this.models.BloodPressure.countDocuments(dateFilter);
  }

  /**
   * For "keep under" goals (mmHg/systolic), being at or below target = success.
   */
  getProgress(goal) {
    const gUnit = goal.unit || "";
    const isKeepUnder = unitMatches(gUnit, "mmhg");

    if (isKeepUnder && goal.targetValue > 0) {
      const completed = goal.currentValue <= goal.targetValue;
      return completed ? 100 : (goal.currentValue > 0 ? Math.max(0, Math.min(Math.round(((goal.targetValue / goal.currentValue)) * 100), 99)) : 0);
    }
    return super.getProgress(goal);
  }

  isCompleted(goal) {
    const gUnit = goal.unit || "";
    const isKeepUnder = unitMatches(gUnit, "mmhg");
    if (isKeepUnder && goal.targetValue > 0) {
      return goal.currentValue <= goal.targetValue;
    }
    return super.isCompleted(goal);
  }
}

module.exports = BloodPressureStrategy;
