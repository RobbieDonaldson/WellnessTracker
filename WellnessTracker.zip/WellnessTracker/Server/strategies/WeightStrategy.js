const GoalProgressStrategy = require("./GoalProgressStrategy");

class WeightStrategy extends GoalProgressStrategy {
  async computeCurrentValue(goal) {
    // Latest weight reading
    const latest = await this.models.Weight.findOne({ userId: goal.userId }).sort({ date: -1 }).lean();
    if (!latest) return 0;

    const unit = (goal.unit || "").toLowerCase().trim();
    if (["kg", "kilograms"].includes(unit)) {
      return latest.unit === "kg" ? latest.value : Math.round(latest.value / 2.205 * 10) / 10;
    }
    return latest.unit === "lbs" ? latest.value : Math.round(latest.value * 2.205 * 10) / 10;
  }

  /**
   * Weight goals use baseline-based progress calculation.
   * Find baseline weight at goal start and compute progress relative to target.
   */
  getProgress(goal) {
    if (!goal.targetValue || goal.targetValue <= 0) return 0;

    // Find baseline weight at goal start
    const baselineQuery = { userId: goal.userId };
    if (goal.startDate) baselineQuery.date = { $gte: goal.startDate };

    // This is synchronous; in production this should be computed in computeCurrentValue
    // For now, we'll return null to let the controller handle it
    return null;
  }

  /**
   * Weight completion is direction-aware (loss vs gain).
   * This is handled in the controller due to needing baseline query.
   */
  isCompleted(goal) {
    // Handled in controller
    return null;
  }
}

module.exports = WeightStrategy;
