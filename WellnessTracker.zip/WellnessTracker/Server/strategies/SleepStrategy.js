const GoalProgressStrategy = require("./GoalProgressStrategy");
const { unitMatches } = require("../utils/unitNormalizer");

class SleepStrategy extends GoalProgressStrategy {
  async computeCurrentValue(goal) {
    const dateFilter = this.buildDateFilter(goal);
    const unit = goal.unit || "";

    // Days/nights: count of nights with ≥ 8 hours of sleep
    if (unitMatches(unit, "day", "night")) {
      const agg = await this.models.Sleep.aggregate([
        { $match: { ...dateFilter, duration: { $gte: 8 } } },
        { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } } } },
      ]);
      return agg.length;
    }

    // Hours: sum of sleep duration
    if (unitMatches(unit, "hour")) {
      const agg = await this.models.Sleep.aggregate([
        { $match: dateFilter },
        { $group: { _id: null, total: { $sum: "$duration" } } },
      ]);
      return Math.round((agg[0]?.total || 0) * 10) / 10;
    }

    // Default: count of sleep entries
    return await this.models.Sleep.countDocuments(dateFilter);
  }
}

module.exports = SleepStrategy;
