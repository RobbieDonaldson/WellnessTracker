const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/goalController");

router.get("/", ctrl.getAll);
router.get("/:id", ctrl.getById);
router.get("/:id/history", ctrl.getHistory);
router.post("/", ctrl.create);
router.put("/:id", ctrl.update);
router.delete("/:id", ctrl.remove);

module.exports = router;
