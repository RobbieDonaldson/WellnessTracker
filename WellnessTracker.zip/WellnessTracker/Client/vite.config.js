import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      "/api": "http://localhost:5000",
      "/avatars": "http://localhost:5000",
    },
  },
  build: {
    outDir: "../Server/public",
    emptyOutDir: true,
    sourcemap: false,
  },
});
